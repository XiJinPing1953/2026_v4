package com.example.scanmanagerdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.device.ScanManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AutoBitmapActivity extends AppCompatActivity {

    private static String BROADCAST_IMAGE_ACTION = "com.ubx.scanner_capture_image_result";
    private ImageView imageView ;
    private TextView textView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_bitmap);
        imageView = findViewById(R.id.iv_bitmap);
        textView = findViewById(R.id.tv_barcode);


        findViewById(R.id.btn_get_bitmap).setVisibility(View.GONE);
        enableAutoSaveImage(this,true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        enableAutoSaveImage(this,false);
    }

    @Override
    protected void onResume() {
        super.onResume();

        setReceiverRegister();
    }
    /**
     * Set up to automatically return pictures
     * 设置自动返回图片
     * @param context
     * @param enableSendImage
     */
    private void enableAutoSaveImage(Context context,boolean enableSendImage){
        try {
            Intent intentImage= new Intent();
            intentImage.setAction("com.ubx.barcode.broadcast_image");

            //设置接收图片结果的action
            // Set the action for receiving picture results
            intentImage.putExtra("imageAction",BROADCAST_IMAGE_ACTION);

            //是否解到条码后就直接广播出图片数据和条码数据
            // Whether to solve the bar code directly broadcast the picture data and bar code data
            intentImage.putExtra("enableSendImage",enableSendImage);

            //是否默认发送解码失败图片 （某些扫码头不支持，具体可咨询我司技术支持）
            //Whether to send the decoding failure picture by default (some docks are not supported, please consult our technical support for details)
            intentImage.putExtra("enableSendFailedImage",enableSendImage);

            //该广播输出图片数据形式 0 bitmap数组 1保存图片输出路径
            // The broadcast output picture data form 0 bitmap array 1 saves the picture output path
            intentImage.putExtra("outputImageMode",0);

            //设置返回图片的质量百分比：1-100，系统默认50(50%)
            // Set the quality percentage of returned images: 1-100, system default 50(50%)
            intentImage.putExtra("jpegQuality", 100);

            //是否返回坐标位置
            // Whether to return the coordinate position
            intentImage.putExtra("outputBounds", true);

            //保存图片后缀类型 0 png 1 jpg 2 bmp
            // Save the image suffix 0 png 1 jpg 2 bmp
            intentImage.putExtra("imageFormat",0);

            //设置图片保存路径
            // Set the image saving path
            intentImage.putExtra("saveImageDirPath","/storage/emulated/0/imageSave/");
            context.sendBroadcast(intentImage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }






    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGetBitmapReceiver);//注销广播
    }

    /**
     *广播接收器
     */
    private BroadcastReceiver mGetBitmapReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action  = intent.getAction();
            Log.i("ScanManager", "onReceive: action:"+action);
              if(intent.getAction().equals(BROADCAST_IMAGE_ACTION)){

                  //获取扫码结果  Obtain the code scan result
                String barcode = intent.getStringExtra("barcode");
                //获取坐标集合  Get coordinate set
                  int[] bounds = intent.getIntArrayExtra("bounds");
                //获取图片名称 例如：123456787654.jpg   Example: 123456787654.jpg
                String imageName = intent.getStringExtra("imageName");
                //获取图像数组   Get image array
                  byte[] bmp = intent.getByteArrayExtra("bitmapBytes");
                if(bmp != null && bmp.length > 1) {

                    Bitmap mBitmap = BitmapFactory.decodeByteArray(bmp, 0, bmp.length).copy(Bitmap.Config.RGB_565, true);
                    imageView.setImageBitmap(mBitmap);

                }else {
                    textView.setText("条码："+barcode+ "\n图片："+bmp);
                    Toast.makeText(AutoBitmapActivity.this, "获取图片失败 " , Toast.LENGTH_SHORT).show();
                }
                  textView.setText("条码："+barcode);
            }
        }
    };

    /**
     *   注册广播
     */
    private void setReceiverRegister() {
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(BROADCAST_IMAGE_ACTION);//TODO 获取码库底层自动返回（或保存）的图片地址的广播注册
            registerReceiver(mGetBitmapReceiver, filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
