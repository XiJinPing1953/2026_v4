package com.example.scanmanagerdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.device.ScanManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ubx.scanner.StatusListener;

public class ManualBitmapActivity extends AppCompatActivity {

    private String action_scanner_capture_image_result = "scanner_capture_image_result";
    private ImageView imageView ;
    private TextView textView;
    private ScanManager mScanManager = new ScanManager();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_bitmap);
        imageView = findViewById(R.id.iv_bitmap);
        textView = findViewById(R.id.tv_barcode);


        findViewById(R.id.btn_get_bitmap).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBitmap();
            }
        });
        


        //监听扫描状态
        mScanManager.addStatusActionListener(new StatusListener() {
            @Override
            public void onStatus(int event, Bundle bundle) {
                //TODO  event   4:开始出光扫描     3：松开按键（停止扫描）  2：扫描超时
                if (event == 3 || event == 2){
                    getBitmap();
                }else if (event == 4){
                    textView.setText("");
                    imageView.setImageBitmap(null);
                }
            }
        });

    }

    private void getBitmap(){
        //发送广播---取图
        String action = "action.scanner_capture_image" ;
        Intent intentImage = new Intent(action);
        sendBroadcast(intentImage);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setReceiverRegister();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGetBitmapReceiver);//注销广播
    }


    /**
     *广播接收器
     */
    private BroadcastReceiver mGetBitmapReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action  = intent.getAction();
            Log.i("ScanManager", "onReceive: action:"+action);
            if (action.equals(ScanManager.ACTION_DECODE)){
                String barcode = intent.getStringExtra(ScanManager.BARCODE_STRING_TAG);
                textView.setText("条码："+barcode);
                getBitmap();

            }else if(action.equals(action_scanner_capture_image_result)) {
                byte[] bmp = intent.getByteArrayExtra("bitmapBytes");
                if(bmp != null && bmp.length > 1) {

                    Bitmap mBitmap = BitmapFactory.decodeByteArray(bmp, 0, bmp.length).copy(Bitmap.Config.RGB_565, true);
                    imageView.setImageBitmap(mBitmap);

                }else {
                    Toast.makeText(ManualBitmapActivity.this, "获取图片失败 " , Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    /**
     *   注册广播
     */
    private void setReceiverRegister() {
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(ScanManager.ACTION_DECODE);
            filter.addAction(action_scanner_capture_image_result);
            registerReceiver(mGetBitmapReceiver, filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
