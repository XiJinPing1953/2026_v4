package com.example.scanmanagerdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.device.ScanManager;
import android.device.scanner.configuration.PropertyID;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.ubx.scanner.StatusListener;



public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView textView;
    private String[] strs;
    private String mAction =  ScanManager.ACTION_DECODE;//"android.provider.sdlMessage";
    private String mKey = ScanManager.BARCODE_STRING_TAG;
    private ScanManager mScanManager = new ScanManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.tv_barcode);

        mScanManager.switchOutputMode(0);//0：开启广播模式   1：键盘模式  0: Enable broadcast mode 1: keyboard mode

        findViewById(R.id.btn_scan_start).setOnClickListener(this);
        findViewById(R.id.btn_scan_stop).setOnClickListener(this);
        findViewById(R.id.btn_auto_bitmap).setOnClickListener(this);
        findViewById(R.id.btn_manual_bitmap).setOnClickListener(this);


        try {
            mScanManager.addStatusActionListener(new StatusListener() {
                @Override
                public void onStatus(int event, Bundle bundle) {
                    //TODO  event   4:开始出光扫描     3：松开按键（停止扫描）  2：扫描超时
                    //TODO event 4: starts optical output scanning 3: Releases the button (stops scanning) 2: scanning times out
                }
            });
        } catch (Throwable e) {
            e.printStackTrace();
        }

    }


    @Override
    public void onClick(View view) {
            switch (view.getId()){
                case R.id.btn_scan_start:
                    mScanManager.startDecode();
                    break;
                case R.id.btn_scan_stop:
                    mScanManager.stopDecode();
                    break;
                case R.id.btn_auto_bitmap:
                        Intent intent = new Intent(MainActivity.this, AutoBitmapActivity.class);
                        startActivity(intent);
                    break;
                case R.id.btn_manual_bitmap:
                    Intent intent2 = new Intent(MainActivity.this, ManualBitmapActivity.class);
                    startActivity(intent2);
                    break;

            }
    }


    @Override
    protected void onResume() {
        super.onResume();
        getRealTimeAction();
        registerReceiver(true);
    }

    /**
     * 实时获取扫描头 ACTION 以及 key 参数
     */
    private void getRealTimeAction() {
        strs = new ScanManager().getParameterString(new int[]{PropertyID.WEDGE_INTENT_ACTION_NAME, PropertyID.WEDGE_INTENT_DATA_STRING_TAG});
        mAction = strs[0];//实时获取的action    Get action in real time
        mKey = strs[1];//实时获取的key          Obtain the key in real time
    }

    @Override
    protected void onPause() {
        super.onPause();
        registerReceiver(false);
    }

    /**
     * @param register , ture register , false unregister
     */
    private void registerReceiver(boolean register) {
        if (register) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(mAction);
            registerReceiver(mReceiver, filter);
        } else {
            unregisterReceiver(mReceiver);
        }
    }


    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {



            String action = intent.getAction();
            if (action.equals(mAction)) {
                String barcodeStr = intent.getStringExtra(mKey);//barcode value  获取扫描的条码数据
                textView.setText(barcodeStr);
                Toast.makeText(context, "扫描成功", Toast.LENGTH_SHORT).show();
            }

        }
    };


}